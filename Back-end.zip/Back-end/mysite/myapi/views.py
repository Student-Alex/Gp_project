# views.py
from rest_framework import viewsets
from .serializers import HeroSerializer, StressSerializer, SleepSerializer
from .models import Hero, Stress, Sleep



class HeroViewSet(viewsets.ModelViewSet):
    queryset = Hero.objects.all().order_by('name')
    serializer_class = HeroSerializer

class StressViewSet(viewsets.ModelViewSet):
    queryset = Stress.objects.all().order_by('tijd')
    serializer_class = StressSerializer

class SleepViewSet(viewsets.ModelViewSet):
    queryset = Sleep.objects.all().order_by ('sleep')
    serializer_class = SleepSerializer
