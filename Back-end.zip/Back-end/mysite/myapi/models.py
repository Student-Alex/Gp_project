# models.py
from django.db import models
class Hero(models.Model):
    name = models.CharField(max_length=60)
    alias = models.CharField(max_length=60)
    huisdieren = models.CharField(max_length=60, default="none")
    def __str__(self):
        return self.name

class Stress(models.Model):
    tijd = models.CharField(max_length=60)
    stresslevel = models.PositiveIntegerField()
    reden = models.CharField(max_length=6000, default="none")
    datum = models.CharField(max_length=60, default ="none")
    def __str__(self):
        return self.tijd

class Sleep(models.Model):
    sleep = models.CharField(max_length=60, default="none")
    day = models.CharField(max_length=60, default="none")
    def __str__(self):
        return self.sleep


#Charfield voor string
#Boolean voor een boolean 
#DateField voor een dag 
#TimeField voor een tijd
#DateTimeField voor allebei
#DecimalField voor decimalen getallen
#IntergerField voor integer 
#PositiveInteger voor alleen positieve getallen


