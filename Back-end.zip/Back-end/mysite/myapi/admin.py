from django.contrib import admin
from .models import Hero, Stress, Sleep
admin.site.register(Hero)
admin.site.register(Stress)
admin.site.register(Sleep)
