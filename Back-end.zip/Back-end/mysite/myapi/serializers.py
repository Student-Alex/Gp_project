# serializers.py
from rest_framework import serializers

from .models import Hero, Stress, Sleep

class HeroSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Hero
        fields = ('id', 'name', 'alias','huisdieren')

class StressSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Stress
        fields = ('id', 'tijd', 'stresslevel','reden', 'datum')

class SleepSerializer(serializers.HyperlinkedModelSerializer):
    class Meta: 
        model = Sleep
        fields = ('id', 'sleep', 'day')
        
        